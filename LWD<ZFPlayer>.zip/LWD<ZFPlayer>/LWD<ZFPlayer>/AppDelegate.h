//
//  AppDelegate.h
//  LWD<ZFPlayer>
//
//  Created by liweidong on 17/7/31.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

