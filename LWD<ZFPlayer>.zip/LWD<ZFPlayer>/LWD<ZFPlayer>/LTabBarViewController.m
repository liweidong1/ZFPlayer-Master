//
//  LiveTVTabBarViewController.m
//  TRProject
//
//  Created by liweidong on 17/4/10.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "LTabBarViewController.h"

#import "ViewController.h"
#import "ZFDownloadViewController.h"


@interface LTabBarViewController ()

@property (nonatomic) ViewController *homeVC;
@property (nonatomic) ZFDownloadViewController *mineVC;


@end

@implementation LTabBarViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    UINavigationController *navi0 = [[UINavigationController alloc] initWithRootViewController:self.homeVC];
    UINavigationController *navi1 = [[UINavigationController alloc] initWithRootViewController:self.mineVC];
    self.viewControllers = @[navi0,navi1];
    
}
#pragma mark - LazyLoad 懒加载
- (ViewController *)homeVC {
    if(_homeVC == nil) {
        _homeVC = [[ViewController alloc] init];
        _homeVC.tabBarItem.image = [UIImage imageNamed:@"placeHolder"];
        _homeVC.title = @"首页";
        _homeVC.tabBarItem.selectedImage = [UIImage imageNamed:@"placeHolder"];
    }
    return _homeVC;
}

- (ZFDownloadViewController *)mineVC {
    if(_mineVC == nil) {
        _mineVC = [[ZFDownloadViewController alloc] init];
        _mineVC.title = @"我的下载";
        _mineVC.tabBarItem.image = [UIImage imageNamed:@"toolbar_me"];
        _mineVC.tabBarItem.selectedImage = [UIImage imageNamed:@"toolbar_me_sel"];
    }
    return _mineVC;
}

@end
