//
//  ViewController.m
//  LWD<ZFPlayer>
//
//  Created by liweidong on 17/7/31.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import "ViewController.h"
#import "MoviePlayerViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIButton *btn = [[UIButton alloc] init];
    btn.backgroundColor = [UIColor redColor];
    [btn setTitle:@"播放URL" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(0);
        make.size.equalTo(CGSizeMake(100, 30));
    }];

}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = NO;
}

-(void)click {
    MoviePlayerViewController *movie = [[MoviePlayerViewController alloc]init];
    NSURL *URL                       = [NSURL URLWithString:@"https://bmob-cdn-11424.b0.upaiyun.com/2017/07/28/11455c1d6a674b3488144cf701a0ca8f.mp4"];
    movie.videoURL                   = URL;
    
    self.navigationController.navigationBar.hidden = YES;
    [self.navigationController pushViewController:movie animated:YES];
}


@end
